//
// Description :  Single linked list
//
#include <iostream>
#include <list>
#include "node.h"

using namespace std;

class LinkedList
{
private:
	Node *head;     // a pointer pints to a head node
	Node *tail;     // a pointer pints to a tail node

public:
	// Constructor: initial value
	LinkedList() {
		// Initial head and tail pointers
		head=NULL;
		tail=NULL;
	}

	// Destructor: deletes everything in the list.
	~LinkedList() {
		Node* node;
		while (head!=NULL) {
			node=head->next;
			delete head;
			head=node;
		}
	}

	bool isEmpty();
	void PushFront(int t);
	void PushBack(int t);
	void PrintNode(Node* n);
	void PrintList();
	void PrintList(Node* startNode);

	Node* FindKthElementFromTail(unsigned int k);
	bool Delete(Node* node);
	void ReverseList();
};

// check if a linked list is empty
bool LinkedList::isEmpty() {
	if (head==NULL) return true;
	else return false;
}
// add a new element at the beginning of a list
void LinkedList::PushFront(int t)
{
	Node* newNode = new Node(t);
	if (isEmpty()) {
		head = newNode;
		tail = newNode;
	} else {
		newNode->next = head;
		head = newNode;
	}
}
// add a new element at the end of a list
void LinkedList::PushBack(int t) 
{
	Node* newNode = new Node(t);
	if (isEmpty()) {
		head = newNode;
		tail = newNode;
	}  else {
		tail->next = newNode;
		tail = newNode;
	}
}
// print the data in a node
void LinkedList::PrintNode(Node* n) 
{
	if (n!=NULL)
		cout << n->payload << endl;
	else
		cout << "NULL" << endl;
}
// print the data in a linked list
void LinkedList::PrintList()  
{
	Node *it = head;
	while (it!=NULL)  
	{
		cout << it->payload << ' ';
		it=it->next;
	}
	cout << endl;
}
// print the data in a linked list from a specific node
void LinkedList::PrintList(Node* startNode)  
{
	Node *it = startNode;
	while (it!=NULL)  
	{
		cout << it->payload << ' ';
		it=it->next;
	}
	cout << endl;
}
// function to reverse a list
void LinkedList::ReverseList()
{
	// add your code here
	/* hints: we can define this problem as a recursion. 
	   You may create other recursive functions as need.
	*/
}
// function to find the k-th element from the back of a list
Node* LinkedList::FindKthElementFromTail(unsigned int k)
{
	// add your code here
	/* hints: there is an algorithm that scan through the linked list only once! 
	   One possibilty is to use two pointers scan a list. I will leave it to you to think about how to used them.
	   Feel free to come up with other algorithm.
	*/
}
// function to delete the specific node from a list
bool LinkedList::Delete (Node* node)
{
	// add your code here
	/* hints: don't forget to consider that there are multiple cases. Some cases take constant time, while some may take longer time.
		1. if the node is head/tail, 
		2. if there is only one element in a list (head=tail)
		3. if the node is an intermediate node (neither head nor tail) 
		please set the correct head and tail pointers after delete, otherwise your list will be in a mess
	*/
}
